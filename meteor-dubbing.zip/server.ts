import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("anime.db");
const JWT_SECRET = process.env.JWT_SECRET || "anime-secret-key";

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    email TEXT UNIQUE,
    password TEXT,
    role TEXT DEFAULT 'user',
    is_premium INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS genres (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE
  );

  CREATE TABLE IF NOT EXISTS anime (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    description TEXT,
    image_url TEXT,
    banner_url TEXT,
    rating REAL DEFAULT 0,
    status TEXT, -- Ongoing, Finished
    type TEXT, -- TV, Movie, OVA
    release_year INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS anime_genres (
    anime_id INTEGER,
    genre_id INTEGER,
    FOREIGN KEY(anime_id) REFERENCES anime(id),
    FOREIGN KEY(genre_id) REFERENCES genres(id)
  );

  CREATE TABLE IF NOT EXISTS episodes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    anime_id INTEGER,
    episode_number INTEGER,
    title TEXT,
    video_url TEXT,
    duration TEXT,
    FOREIGN KEY(anime_id) REFERENCES anime(id)
  );

  CREATE TABLE IF NOT EXISTS watchlist (
    user_id INTEGER,
    anime_id INTEGER,
    PRIMARY KEY(user_id, anime_id),
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(anime_id) REFERENCES anime(id)
  );

  CREATE TABLE IF NOT EXISTS history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    anime_id INTEGER,
    episode_id INTEGER,
    watched_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(anime_id) REFERENCES anime(id),
    FOREIGN KEY(episode_id) REFERENCES episodes(id)
  );

  CREATE TABLE IF NOT EXISTS news (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    content TEXT,
    image_url TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    anime_id INTEGER,
    episode_id INTEGER,
    content TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(anime_id) REFERENCES anime(id),
    FOREIGN KEY(episode_id) REFERENCES episodes(id)
  );
`);

// Seed initial data if empty
const userCount = db.prepare("SELECT COUNT(*) as count FROM users").get() as { count: number };
const hashedPassword = bcrypt.hashSync("meteor_admin_2026", 10);

if (userCount.count === 0) {
  db.prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)").run("admin", "admin@meteordubbing.com", hashedPassword, "admin");
  
  // Seed Genres
  const genres = ["Jangari", "Sarguzasht", "Komediya", "Drama", "Fantastika", "Qo'rqinchli", "Detektiv", "Romantika", "Ilmiy-fantastika", "Kundalik hayot"];
  const insertGenre = db.prepare("INSERT INTO genres (name) VALUES (?)");
  genres.forEach(g => insertGenre.run(g));
} else {
  // Update existing admin password and email just in case
  db.prepare("UPDATE users SET email = ?, password = ? WHERE role = 'admin'").run("admin@meteordubbing.com", hashedPassword);
}

// Clear all anime data as requested (Commented out after execution)
// db.prepare("DELETE FROM anime_genres").run();
// db.prepare("DELETE FROM episodes").run();
// db.prepare("DELETE FROM watchlist").run();
// db.prepare("DELETE FROM history").run();
// db.prepare("DELETE FROM comments").run();
// db.prepare("DELETE FROM anime").run();

// Add sample data if empty
const animeCount = db.prepare("SELECT COUNT(*) as count FROM anime").get() as { count: number };
if (animeCount.count === 0) {
  const animeId = db.prepare("INSERT INTO anime (title, description, image_url, rating, status, type, release_year) VALUES (?, ?, ?, ?, ?, ?, ?)").run(
    "Solo Leveling",
    "O'n yil oldin 'Darvoza' paydo bo'lib, insoniyat dunyosini boshqa o'lcham bilan bog'laganidan so'ng, ba'zi oddiy odamlar Darvoza ichidagi yirtqich hayvonlarni ovlash qobiliyatiga ega bo'lishdi.",
    "https://picsum.photos/seed/solo/600/900",
    9.2,
    "Davom etmoqda",
    "TV",
    2024
  ).lastInsertRowid;

  db.prepare("INSERT INTO episodes (anime_id, episode_number, title, video_url, duration) VALUES (?, ?, ?, ?, ?)").run(
    animeId,
    1,
    "Men tirikman",
    "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    "24:00"
  );

  const genreId = db.prepare("SELECT id FROM genres WHERE name = 'Jangari'").get() as { id: number };
  if (genreId) {
    db.prepare("INSERT INTO anime_genres (anime_id, genre_id) VALUES (?, ?)").run(animeId, genreId.id);
  }
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // --- AUTH ROUTES ---
  app.post("/api/auth/register", (req, res) => {
    const { username, email, password } = req.body;
    try {
      const hashedPassword = bcrypt.hashSync(password, 10);
      const result = db.prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)").run(username, email, hashedPassword);
      const user = db.prepare("SELECT id, username, email, role, is_premium FROM users WHERE id = ?").get(result.lastInsertRowid);
      const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET);
      res.json({ token, user });
    } catch (e: any) {
      res.status(400).json({ error: e.message });
    }
  });

  app.post("/api/auth/login", (req, res) => {
    const { email, password } = req.body;
    const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email) as any;
    if (user && bcrypt.compareSync(password, user.password)) {
      const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET);
      const { password: _, ...userWithoutPassword } = user;
      res.json({ token, user: userWithoutPassword });
    } else {
      res.status(401).json({ error: "Invalid credentials" });
    }
  });

  // Middleware for Auth
  const authenticate = (req: any, res: any, next: any) => {
    const token = req.headers.authorization?.split(" ")[1];
    if (!token) return res.status(401).json({ error: "Unauthorized" });
    try {
      req.user = jwt.verify(token, JWT_SECRET);
      next();
    } catch (e) {
      res.status(401).json({ error: "Invalid token" });
    }
  };

  const isAdmin = (req: any, res: any, next: any) => {
    if (req.user?.role !== 'admin') return res.status(403).json({ error: "Forbidden" });
    next();
  };

  // --- ANIME ROUTES ---
  app.get("/api/anime", (req, res) => {
    const { genre, search, sort } = req.query;
    let query = `
      SELECT a.*, GROUP_CONCAT(g.name) as genres 
      FROM anime a
      LEFT JOIN anime_genres ag ON a.id = ag.anime_id
      LEFT JOIN genres g ON ag.genre_id = g.id
    `;
    const params: any[] = [];
    const conditions: string[] = [];

    if (genre) {
      conditions.push(`a.id IN (SELECT anime_id FROM anime_genres ag JOIN genres g ON ag.genre_id = g.id WHERE g.name = ?)`);
      params.push(genre);
    }
    if (search) {
      conditions.push(`a.title LIKE ?`);
      params.push(`%${search}%`);
    }
    if (req.query.status) {
      conditions.push(`a.status = ?`);
      params.push(req.query.status);
    }

    if (conditions.length > 0) {
      query += ` WHERE ` + conditions.join(" AND ");
    }

    query += ` GROUP BY a.id`;

    if (sort === "popular") query += ` ORDER BY rating DESC`;
    else if (sort === "new") query += ` ORDER BY release_year DESC`;
    else query += ` ORDER BY created_at DESC`;

    const anime = db.prepare(query).all(...params);
    res.json(anime);
  });

  app.get("/api/anime/:id", (req, res) => {
    const anime = db.prepare(`
      SELECT a.*, GROUP_CONCAT(g.name) as genres 
      FROM anime a
      LEFT JOIN anime_genres ag ON a.id = ag.anime_id
      LEFT JOIN genres g ON ag.genre_id = g.id
      WHERE a.id = ?
      GROUP BY a.id
    `).get(req.params.id);
    
    if (!anime) return res.status(404).json({ error: "Anime not found" });
    
    const episodes = db.prepare("SELECT * FROM episodes WHERE anime_id = ? ORDER BY episode_number ASC").all(req.params.id);
    const comments = db.prepare(`
      SELECT c.*, u.username 
      FROM comments c 
      JOIN users u ON c.user_id = u.id 
      WHERE c.anime_id = ? 
      ORDER BY c.created_at DESC
    `).all(req.params.id);
    
    res.json({ ...anime, episodes, comments });
  });

  app.get("/api/episodes/:id", (req, res) => {
    const episode = db.prepare("SELECT * FROM episodes WHERE id = ?").get(req.params.id) as any;
    if (!episode) return res.status(404).json({ error: "Episode not found" });
    
    const anime = db.prepare("SELECT title FROM anime WHERE id = ?").get(episode.anime_id);
    const comments = db.prepare(`
      SELECT c.*, u.username 
      FROM comments c 
      JOIN users u ON c.user_id = u.id 
      WHERE c.episode_id = ? 
      ORDER BY c.created_at DESC
    `).all(req.params.id);

    const nextEpisode = db.prepare("SELECT id FROM episodes WHERE anime_id = ? AND episode_number > ? ORDER BY episode_number ASC LIMIT 1").get(episode.anime_id, episode.episode_number);
    const prevEpisode = db.prepare("SELECT id FROM episodes WHERE anime_id = ? AND episode_number < ? ORDER BY episode_number DESC LIMIT 1").get(episode.anime_id, episode.episode_number);

    res.json({ ...episode, anime_title: (anime as any)?.title, comments, next_id: (nextEpisode as any)?.id, prev_id: (prevEpisode as any)?.id });
  });

  // --- USER ACTIONS ---
  app.post("/api/watchlist", authenticate, (req: any, res) => {
    const { anime_id } = req.body;
    try {
      db.prepare("INSERT INTO watchlist (user_id, anime_id) VALUES (?, ?)").run(req.user.id, anime_id);
      res.json({ success: true });
    } catch (e) {
      db.prepare("DELETE FROM watchlist WHERE user_id = ? AND anime_id = ?").run(req.user.id, anime_id);
      res.json({ success: true, removed: true });
    }
  });

  app.get("/api/watchlist", authenticate, (req: any, res) => {
    const list = db.prepare(`
      SELECT a.* FROM anime a
      JOIN watchlist w ON a.id = w.anime_id
      WHERE w.user_id = ?
    `).all(req.user.id);
    res.json(list);
  });

  app.post("/api/history", authenticate, (req: any, res) => {
    const { anime_id, episode_id } = req.body;
    db.prepare("INSERT INTO history (user_id, anime_id, episode_id) VALUES (?, ?, ?)").run(req.user.id, anime_id, episode_id);
    res.json({ success: true });
  });

  app.get("/api/history", authenticate, (req: any, res) => {
    const list = db.prepare(`
      SELECT h.*, a.title as anime_title, a.image_url, e.episode_number, e.title as episode_title
      FROM history h
      JOIN anime a ON h.anime_id = a.id
      JOIN episodes e ON h.episode_id = e.id
      WHERE h.user_id = ?
      ORDER BY h.watched_at DESC
      LIMIT 20
    `).all(req.user.id);
    res.json(list);
  });

  app.post("/api/comments", authenticate, (req: any, res) => {
    const { anime_id, episode_id, content } = req.body;
    db.prepare("INSERT INTO comments (user_id, anime_id, episode_id, content) VALUES (?, ?, ?, ?)").run(req.user.id, anime_id, episode_id, content);
    res.json({ success: true });
  });

  // --- NEWS ---
  app.get("/api/news", (req, res) => {
    const news = db.prepare("SELECT * FROM news ORDER BY created_at DESC").all();
    res.json(news);
  });

  // --- GENRES ---
  app.get("/api/genres", (req, res) => {
    const genres = db.prepare("SELECT * FROM genres").all();
    res.json(genres);
  });

  // --- ADMIN ROUTES ---
  app.get("/api/admin/stats", authenticate, isAdmin, (req, res) => {
    const users = db.prepare("SELECT COUNT(*) as count FROM users").get();
    const anime = db.prepare("SELECT COUNT(*) as count FROM anime").get();
    const episodes = db.prepare("SELECT COUNT(*) as count FROM episodes").get();
    const comments = db.prepare("SELECT COUNT(*) as count FROM comments").get();
    res.json({ users, anime, episodes, comments });
  });

  app.get("/api/admin/users", authenticate, isAdmin, (req, res) => {
    const users = db.prepare("SELECT id, username, email, role, is_premium, created_at FROM users").all();
    res.json(users);
  });

  app.post("/api/admin/users/:id/premium", authenticate, isAdmin, (req, res) => {
    const { is_premium } = req.body;
    db.prepare("UPDATE users SET is_premium = ? WHERE id = ?").run(is_premium ? 1 : 0, req.params.id);
    res.json({ success: true });
  });

  app.post("/api/admin/anime", authenticate, isAdmin, (req, res) => {
    const { title, description, image_url, rating, status, type, release_year, genres } = req.body;
    const result = db.prepare("INSERT INTO anime (title, description, image_url, rating, status, type, release_year) VALUES (?, ?, ?, ?, ?, ?, ?)").run(title, description, image_url, rating, status, type, release_year);
    const animeId = result.lastInsertRowid;
    if (genres && Array.isArray(genres)) {
      const insertGenre = db.prepare("INSERT INTO anime_genres (anime_id, genre_id) VALUES (?, ?)");
      genres.forEach((gId: number) => insertGenre.run(animeId, gId));
    }
    res.json({ success: true, id: animeId });
  });

  app.put("/api/admin/anime/:id", authenticate, isAdmin, (req, res) => {
    const { title, description, image_url, rating, status, type, release_year, genres } = req.body;
    db.prepare("UPDATE anime SET title = ?, description = ?, image_url = ?, rating = ?, status = ?, type = ?, release_year = ? WHERE id = ?")
      .run(title, description, image_url, rating, status, type, release_year, req.params.id);
    
    if (genres && Array.isArray(genres)) {
      db.prepare("DELETE FROM anime_genres WHERE anime_id = ?").run(req.params.id);
      const insertGenre = db.prepare("INSERT INTO anime_genres (anime_id, genre_id) VALUES (?, ?)");
      genres.forEach((gId: number) => insertGenre.run(req.params.id, gId));
    }
    res.json({ success: true });
  });

  app.delete("/api/admin/anime/:id", authenticate, isAdmin, (req, res) => {
    const animeId = req.params.id;
    try {
      db.transaction(() => {
        db.prepare("DELETE FROM anime_genres WHERE anime_id = ?").run(animeId);
        db.prepare("DELETE FROM history WHERE anime_id = ?").run(animeId);
        db.prepare("DELETE FROM comments WHERE anime_id = ?").run(animeId);
        db.prepare("DELETE FROM watchlist WHERE anime_id = ?").run(animeId);
        db.prepare("DELETE FROM episodes WHERE anime_id = ?").run(animeId);
        db.prepare("DELETE FROM anime WHERE id = ?").run(animeId);
      })();
      res.json({ success: true });
    } catch (error) {
      console.error("Anime deletion error:", error);
      res.status(500).json({ error: "Animeni o'chirishda xatolik yuz berdi" });
    }
  });

  app.post("/api/admin/episodes", authenticate, isAdmin, (req, res) => {
    const { anime_id, episode_number, title, video_url, duration } = req.body;
    const result = db.prepare("INSERT INTO episodes (anime_id, episode_number, title, video_url, duration) VALUES (?, ?, ?, ?, ?)")
      .run(anime_id, episode_number, title, video_url, duration);
    res.json({ success: true, id: result.lastInsertRowid });
  });

  app.put("/api/admin/episodes/:id", authenticate, isAdmin, (req, res) => {
    const { episode_number, title, video_url, duration } = req.body;
    db.prepare("UPDATE episodes SET episode_number = ?, title = ?, video_url = ?, duration = ? WHERE id = ?")
      .run(episode_number, title, video_url, duration, req.params.id);
    res.json({ success: true });
  });

  app.delete("/api/admin/episodes/:id", authenticate, isAdmin, (req, res) => {
    try {
      db.prepare("DELETE FROM history WHERE episode_id = ?").run(req.params.id);
      db.prepare("DELETE FROM comments WHERE episode_id = ?").run(req.params.id);
      db.prepare("DELETE FROM episodes WHERE id = ?").run(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Episode deletion error:", error);
      res.status(500).json({ error: "Qismni o'chirishda xatolik yuz berdi" });
    }
  });

  app.post("/api/admin/news", authenticate, isAdmin, (req, res) => {
    const { title, content, image_url } = req.body;
    const result = db.prepare("INSERT INTO news (title, content, image_url) VALUES (?, ?, ?)").run(title, content, image_url);
    res.json({ success: true, id: result.lastInsertRowid });
  });

  app.put("/api/admin/news/:id", authenticate, isAdmin, (req, res) => {
    const { title, content, image_url } = req.body;
    db.prepare("UPDATE news SET title = ?, content = ?, image_url = ? WHERE id = ?")
      .run(title, content, image_url, req.params.id);
    res.json({ success: true });
  });

  app.delete("/api/admin/news/:id", authenticate, isAdmin, (req, res) => {
    try {
      db.prepare("DELETE FROM news WHERE id = ?").run(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("News deletion error:", error);
      res.status(500).json({ error: "Yangilikni o'chirishda xatolik yuz berdi" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  const PORT = 3000;
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
