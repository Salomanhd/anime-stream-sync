import { BrowserRouter as Router, Routes, Route, Link, useNavigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { Home } from './pages/Home';
import { AnimeDetails } from './pages/AnimeDetails';
import { Episode } from './pages/Episode';
import { Catalog } from './pages/Catalog';
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { Profile } from './pages/Profile';
import { Watchlist } from './pages/Watchlist';
import { AdminDashboard } from './pages/admin/Dashboard';
import { AdminAnime } from './pages/admin/Anime';
import { AdminEpisodes } from './pages/admin/Episodes';
import { AdminUsers } from './pages/admin/Users';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';

import { AdminNews } from './pages/admin/News';

function AppRoutes() {
  const { user, loading } = useAuth();

  if (loading) return <div className="min-h-screen bg-[#0a0502] flex items-center justify-center text-white">Loading...</div>;

  return (
    <div className="min-h-screen bg-[#0a0502] text-white font-sans">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/catalog" element={<Catalog />} />
          <Route path="/anime/:id" element={<AnimeDetails />} />
          <Route path="/episode/:id" element={<Episode />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/watchlist" element={<Watchlist />} />
          
          {/* Admin Routes */}
          {user?.role === 'admin' && (
            <>
              <Route path="/admin" element={<AdminDashboard />} />
              <Route path="/admin/anime" element={<AdminAnime />} />
              <Route path="/admin/anime/:animeId/episodes" element={<AdminEpisodes />} />
              <Route path="/admin/users" element={<AdminUsers />} />
              <Route path="/admin/news" element={<AdminNews />} />
            </>
          )}
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <AppRoutes />
      </Router>
    </AuthProvider>
  );
}
