import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useApi } from '../hooks/useApi';
import { useAuth } from '../contexts/AuthContext';
import { ChevronLeft, ChevronRight, MessageSquare, Send, Star } from 'lucide-react';

export function Episode() {
  const { id } = useParams();
  const api = useApi();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [episode, setEpisode] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [comment, setComment] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await api.get(`/api/episodes/${id}`);
        setEpisode(data);
        if (user) {
          await api.post('/api/history', { anime_id: data.anime_id, episode_id: id });
        }
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [id, user]);

  const handleComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return navigate('/login');
    if (!comment.trim()) return;
    try {
      await api.post('/api/comments', { episode_id: id, content: comment });
      setComment('');
      const data = await api.get(`/api/episodes/${id}`);
      setEpisode(data);
    } catch (e) {
      console.error(e);
    }
  };

  const getYouTubeEmbedUrl = (url: string) => {
    if (!url) return null;
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = url.match(regExp);
    if (match && match[2].length === 11) {
      return `https://www.youtube.com/embed/${match[2]}`;
    }
    return null;
  };

  if (loading) return <div className="py-20 text-center">Loading episode...</div>;
  if (!episode) return <div className="py-20 text-center">Episode not found.</div>;

  const youtubeUrl = getYouTubeEmbedUrl(episode.video_url);

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <Link to={`/anime/${episode.anime_id}`} className="text-orange-500 hover:text-orange-400 text-sm font-bold flex items-center gap-1">
            <ChevronLeft size={16} />
            {episode.anime_title} sahifasiga qaytish
          </Link>
          <h1 className="text-2xl font-bold tracking-tight">
            {episode.episode_number}-qism: {episode.title}
          </h1>
        </div>
      </div>

      {/* Video Player */}
      <div className="aspect-video bg-black rounded-3xl overflow-hidden shadow-2xl border border-white/5 relative group">
        {youtubeUrl ? (
          <iframe
            src={youtubeUrl}
            className="w-full h-full"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            title={episode.title}
          />
        ) : (
          <video 
            src={episode.video_url} 
            controls 
            className="w-full h-full"
            poster={`https://picsum.photos/seed/ep-${id}/1280/720`}
          />
        )}
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between bg-white/5 p-4 rounded-2xl border border-white/10">
        <button 
          disabled={!episode.prev_id}
          onClick={() => navigate(`/episode/${episode.prev_id}`)}
          className="flex items-center gap-2 px-6 py-2 rounded-xl font-bold disabled:opacity-30 hover:bg-white/5 transition-all"
        >
          <ChevronLeft size={20} />
          Oldingi
        </button>
        <div className="text-sm font-medium text-white/50">
          {episode.episode_number}-qism
        </div>
        <button 
          disabled={!episode.next_id}
          onClick={() => navigate(`/episode/${episode.next_id}`)}
          className="flex items-center gap-2 px-6 py-2 rounded-xl font-bold disabled:opacity-30 hover:bg-white/5 transition-all"
        >
          Keyingi
          <ChevronRight size={20} />
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-8">
          {/* Comments */}
          <section className="space-y-8">
            <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
              <MessageSquare size={24} />
              Muhokama
            </h2>
            
            <form onSubmit={handleComment} className="relative">
              <textarea 
                placeholder="Ushbu qism haqida fikringiz..."
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 pr-16 min-h-[100px] focus:outline-none focus:border-orange-500/50 resize-none"
              />
              <button 
                type="submit"
                className="absolute bottom-4 right-4 bg-orange-600 hover:bg-orange-700 p-2 rounded-xl transition-all"
              >
                <Send size={20} />
              </button>
            </form>

            <div className="space-y-6">
              {episode.comments?.map((c: any) => (
                <div key={c.id} className="flex gap-4">
                  <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center font-bold text-orange-500 shrink-0">
                    {c.username[0].toUpperCase()}
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm">{c.username}</span>
                      <span className="text-[10px] text-white/30">{new Date(c.created_at).toLocaleDateString()}</span>
                    </div>
                    <p className="text-sm text-white/70">{c.content}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>

        <div className="space-y-8">
          <div className="bg-white/5 rounded-3xl p-6 border border-white/10">
            <h3 className="font-bold mb-4 text-orange-500 uppercase tracking-widest text-xs">Qism ma'lumotlari</h3>
            <div className="space-y-4 text-sm">
              <div className="flex justify-between">
                <span className="text-white/50">Davomiyligi</span>
                <span>{episode.duration}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/50">Chiqarilgan sana</span>
                <span>{new Date().toLocaleDateString()}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
