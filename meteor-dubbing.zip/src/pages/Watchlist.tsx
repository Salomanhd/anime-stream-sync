import { useState, useEffect } from 'react';
import { useApi } from '../hooks/useApi';
import { Link } from 'react-router-dom';
import { Star, Play, Trash2 } from 'lucide-react';
import { motion } from 'motion/react';

export function Watchlist() {
  const api = useApi();
  const [watchlist, setWatchlist] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchWatchlist = async () => {
    try {
      const data = await api.get('/api/watchlist');
      setWatchlist(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWatchlist();
  }, []);

  const handleRemove = async (id: number) => {
    try {
      await api.post('/api/watchlist', { anime_id: id });
      fetchWatchlist();
    } catch (e) {
      console.error(e);
    }
  };

  if (loading) return <div className="py-20 text-center">Yuklanmoqda...</div>;

  return (
    <div className="space-y-8">
      <h1 className="text-4xl font-bold tracking-tight">Saqlangan animelar</h1>
      
      {watchlist.length === 0 ? (
        <div className="py-20 text-center text-white/50 bg-white/5 rounded-[3rem] border border-dashed border-white/10">
          Saqlangan animelar ro'yxati bo'sh. Keyinroq ko'rish uchun anime qo'shing!
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
          {watchlist.map((item, idx) => (
            <motion.div 
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              className="group relative"
            >
              <button 
                onClick={() => handleRemove(item.id)}
                className="absolute top-2 left-2 z-10 bg-red-600 p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-700"
                title="Remove from watchlist"
              >
                <Trash2 size={14} />
              </button>
              <Link to={`/anime/${item.id}`}>
                <div className="relative aspect-[2/3] rounded-xl overflow-hidden mb-3">
                  <img 
                    src={item.image_url} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <div className="bg-orange-600 p-3 rounded-full transform scale-0 group-hover:scale-100 transition-transform">
                      <Play size={24} fill="currentColor" />
                    </div>
                  </div>
                  <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-md px-2 py-1 rounded text-[10px] font-bold flex items-center gap-1">
                    <Star size={10} className="text-orange-500" fill="currentColor" />
                    {item.rating}
                  </div>
                </div>
                <h3 className="font-bold text-sm line-clamp-1 group-hover:text-orange-500 transition-colors">{item.title}</h3>
                <p className="text-xs text-white/50">{item.release_year} • {item.type}</p>
              </Link>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
