import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useApi } from '../hooks/useApi';
import { useAuth } from '../contexts/AuthContext';
import { Play, Star, Bookmark, Share2, MessageSquare, Send } from 'lucide-react';
import { motion } from 'motion/react';

export function AnimeDetails() {
  const { id } = useParams();
  const api = useApi();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [anime, setAnime] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [comment, setComment] = useState('');
  const [inWatchlist, setInWatchlist] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await api.get(`/api/anime/${id}`);
        setAnime(data);
        if (user) {
          const watchlist = await api.get('/api/watchlist');
          setInWatchlist(watchlist.some((w: any) => w.id === parseInt(id!)));
        }
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [id, user]);

  const handleWatchlist = async () => {
    if (!user) return navigate('/login');
    try {
      await api.post('/api/watchlist', { anime_id: id });
      setInWatchlist(!inWatchlist);
    } catch (e) {
      console.error(e);
    }
  };

  const handleComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return navigate('/login');
    if (!comment.trim()) return;
    try {
      await api.post('/api/comments', { anime_id: id, content: comment });
      setComment('');
      // Refresh comments
      const data = await api.get(`/api/anime/${id}`);
      setAnime(data);
    } catch (e) {
      console.error(e);
    }
  };

  if (loading) return <div className="py-20 text-center">Loading anime details...</div>;
  if (!anime) return <div className="py-20 text-center">Anime not found.</div>;

  return (
    <div className="space-y-12">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row gap-8 items-start md:items-end">
        <div className="w-48 aspect-[2/3] rounded-2xl overflow-hidden shadow-2xl border-4 border-white/10 shrink-0">
          <img 
            src={anime.image_url} 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="space-y-4 pb-4">
          <div className="flex flex-wrap gap-2">
            {anime.genres?.split(',')?.filter(Boolean)?.map((g: string) => (
              <span key={g} className="bg-orange-600/20 text-orange-500 border border-orange-500/30 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
                {g}
              </span>
            ))}
          </div>
          <h1 className="text-4xl md:text-6xl font-bold tracking-tighter">{anime.title}</h1>
          <div className="flex items-center gap-6 text-sm font-medium text-white/70">
            <div className="flex items-center gap-1">
              <Star size={16} className="text-orange-500" fill="currentColor" />
              <span className="text-white">{anime.rating}</span>
            </div>
            <span>{anime.release_year}</span>
            <span>{anime.type}</span>
            <span>{anime.status}</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-12">
          {/* Description */}
          <section className="space-y-4">
            <h2 className="text-2xl font-bold tracking-tight">Annotatsiya</h2>
            <p className="text-white/70 leading-relaxed text-lg">
              {anime.description}
            </p>
            <div className="flex items-center gap-4 pt-4">
              <button 
                onClick={handleWatchlist}
                className={`flex items-center gap-2 px-6 py-3 rounded-full font-bold transition-all ${inWatchlist ? 'bg-orange-600 text-white' : 'bg-white/10 hover:bg-white/20 text-white'}`}
              >
                <Bookmark size={20} fill={inWatchlist ? 'currentColor' : 'none'} />
                {inWatchlist ? "Saqlanganlarda" : "Saqlash"}
              </button>
              <button className="p-3 bg-white/10 hover:bg-white/20 rounded-full transition-all">
                <Share2 size={20} />
              </button>
            </div>
          </section>

          {/* Episodes */}
          <section className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold tracking-tight">Qismlar</h2>
              <span className="text-sm text-white/50">{anime.episodes?.length || 0} qism</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {anime.episodes?.map((ep: any) => (
                <Link 
                  key={ep.id} 
                  to={`/episode/${ep.id}`}
                  className="bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl p-4 flex items-center gap-4 group transition-all"
                >
                  <div className="w-12 h-12 bg-orange-600/20 text-orange-500 rounded-xl flex items-center justify-center font-bold text-lg shrink-0 group-hover:bg-orange-600 group-hover:text-white transition-all">
                    {ep.episode_number}
                  </div>
                  <div className="min-w-0">
                    <h3 className="font-bold text-sm truncate">{ep.title}</h3>
                    <p className="text-xs text-white/40">{ep.duration}</p>
                  </div>
                  <Play size={16} className="ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
                </Link>
              ))}
            </div>
          </section>

          {/* Comments */}
          <section className="space-y-8">
            <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
              <MessageSquare size={24} />
              Fikrlar
            </h2>
            
            <form onSubmit={handleComment} className="relative">
              <textarea 
                placeholder="Fikringizni qoldiring..."
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 pr-16 min-h-[100px] focus:outline-none focus:border-orange-500/50 resize-none"
              />
              <button 
                type="submit"
                className="absolute bottom-4 right-4 bg-orange-600 hover:bg-orange-700 p-2 rounded-xl transition-all"
              >
                <Send size={20} />
              </button>
            </form>

            <div className="space-y-6">
              {anime.comments?.map((c: any) => (
                <div key={c.id} className="flex gap-4">
                  <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center font-bold text-orange-500 shrink-0">
                    {c.username[0].toUpperCase()}
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm">{c.username}</span>
                      <span className="text-[10px] text-white/30">{new Date(c.created_at).toLocaleDateString()}</span>
                    </div>
                    <p className="text-sm text-white/70">{c.content}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>

        {/* Sidebar */}
        <div className="space-y-8">
          <div className="bg-white/5 rounded-3xl p-6 border border-white/10">
            <h3 className="font-bold mb-4 text-orange-500 uppercase tracking-widest text-xs">Anime ma'lumotlari</h3>
            <div className="space-y-4 text-sm">
              <div className="flex justify-between">
                <span className="text-white/50">Turi</span>
                <span>{anime.type}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/50">Holati</span>
                <span>{anime.status}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/50">Chiqarilgan yili</span>
                <span>{anime.release_year}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/50">Reyting</span>
                <span className="flex items-center gap-1">
                  <Star size={14} className="text-orange-500" fill="currentColor" />
                  {anime.rating}
                </span>
              </div>
            </div>
          </div>

          <div className="bg-orange-600 rounded-3xl p-6 text-white space-y-4">
            <h3 className="text-xl font-bold">Premiumga o'ting!</h3>
            <p className="text-sm text-white/80">Sevimli ijodkorlaringizni qo'llab-quvvatlang va reklamasiz tomosha qilish, oflayn ko'rish va yangi qismlarga erta kirish imkoniyatiga ega bo'ling.</p>
            <button className="w-full bg-white text-orange-600 font-bold py-3 rounded-2xl hover:bg-white/90 transition-all">
              Hozir yangilang
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
