import React, { useState, useEffect } from 'react';
import { useApi } from '../../hooks/useApi';
import { Plus, Trash2, Edit2, PlayCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

export function AdminAnime() {
  const api = useApi();
  const [anime, setAnime] = useState<any[]>([]);
  const [genres, setGenres] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingAnime, setEditingAnime] = useState<any>(null);
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    image_url: '',
    rating: 0,
    status: 'Davom etmoqda',
    type: 'TV',
    release_year: new Date().getFullYear(),
    genres: [] as number[]
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [animeData, genreData] = await Promise.all([
        api.get('/api/anime'),
        api.get('/api/genres')
      ]);
      setAnime(animeData);
      setGenres(genreData);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingAnime) {
        await api.put(`/api/admin/anime/${editingAnime.id}`, formData);
      } else {
        await api.post('/api/admin/anime', formData);
      }
      setShowModal(false);
      setEditingAnime(null);
      fetchData();
      resetForm();
    } catch (e) {
      console.error(e);
    }
  };

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      image_url: '',
      rating: 0,
      status: 'Davom etmoqda',
      type: 'TV',
      release_year: new Date().getFullYear(),
      genres: []
    });
  };

  const handleEdit = (item: any) => {
    setEditingAnime(item);
    setFormData({
      title: item.title,
      description: item.description,
      image_url: item.image_url,
      rating: item.rating,
      status: item.status,
      type: item.type,
      release_year: item.release_year,
      genres: [] // Genres handling could be more complex, but for now we reset
    });
    setShowModal(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Ushbu animeni o\'chirishga ishonchingiz komilmi? Barcha qismlar ham o\'chib ketadi.')) return;
    try {
      await api.delete(`/api/admin/anime/${id}`);
      fetchData();
    } catch (e: any) {
      console.error(e);
      alert(e.message || 'O\'chirishda xatolik yuz berdi');
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-4xl font-bold tracking-tight">Animelarni boshqarish</h1>
        <button 
          onClick={() => {
            setEditingAnime(null);
            resetForm();
            setShowModal(true);
          }}
          className="bg-orange-600 hover:bg-orange-700 text-white px-6 py-3 rounded-2xl font-bold flex items-center gap-2 transition-all"
        >
          <Plus size={20} />
          Yangi anime qo'shish
        </button>
      </div>

      <div className="bg-white/5 rounded-[2.5rem] border border-white/10 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[600px]">
            <thead>
              <tr className="bg-white/5 text-white/50 text-xs font-bold uppercase tracking-widest">
                <th className="px-6 py-4">Anime</th>
                <th className="px-6 py-4">Turi</th>
                <th className="px-6 py-4">Holati</th>
                <th className="px-6 py-4">Reyting</th>
                <th className="px-6 py-4 text-right">Amallar</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {anime.map((item) => (
                <tr key={item.id} className="hover:bg-white/5 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-4">
                      <img src={item.image_url} className="w-10 h-14 object-cover rounded-lg" referrerPolicy="no-referrer" />
                      <div>
                        <p className="font-bold text-sm">{item.title}</p>
                        <p className="text-xs text-white/40">{item.release_year}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm">{item.type}</td>
                  <td className="px-6 py-4">
                    <span className={`text-[10px] font-bold px-2 py-1 rounded-full ${item.status === 'Davom etmoqda' ? 'bg-green-500/10 text-green-500' : 'bg-blue-500/10 text-blue-500'}`}>
                      {item.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm font-bold text-orange-500">{item.rating}</td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Link 
                        to={`/admin/anime/${item.id}/episodes`}
                        className="p-2 hover:bg-white/10 rounded-lg text-white/50 hover:text-orange-500 transition-colors"
                        title="Qismlar"
                      >
                        <PlayCircle size={16} />
                      </Link>
                      <button 
                        onClick={() => handleEdit(item)}
                        className="p-2 hover:bg-white/10 rounded-lg text-white/50 hover:text-white transition-colors"
                        title="Tahrirlash"
                      >
                        <Edit2 size={16} />
                      </button>
                      <button 
                        onClick={() => handleDelete(item.id)}
                        className="p-2 hover:bg-red-500/10 rounded-lg text-white/50 hover:text-red-500 transition-colors"
                        title="O'chirish"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#1a1a1a] w-full max-w-2xl rounded-[2.5rem] border border-white/10 p-8 max-h-[90vh] overflow-y-auto space-y-8">
            <h2 className="text-2xl font-bold">{editingAnime ? 'Animeni tahrirlash' : 'Yangi anime qo\'shish'}</h2>
            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1 md:col-span-2">
                <label className="text-xs font-bold uppercase tracking-widest text-white/50">Nomi</label>
                <input 
                  type="text" required
                  value={formData.title}
                  onChange={(e) => setFormData({...formData, title: e.target.value})}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-orange-500"
                />
              </div>
              <div className="space-y-1 md:col-span-2">
                <label className="text-xs font-bold uppercase tracking-widest text-white/50">Tavsif</label>
                <textarea 
                  required
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-orange-500 min-h-[100px]"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold uppercase tracking-widest text-white/50">Rasm URL</label>
                <input 
                  type="text" required
                  value={formData.image_url}
                  onChange={(e) => setFormData({...formData, image_url: e.target.value})}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-orange-500"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold uppercase tracking-widest text-white/50">Reyting</label>
                <input 
                  type="number" step="0.1" required
                  value={formData.rating}
                  onChange={(e) => setFormData({...formData, rating: parseFloat(e.target.value)})}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-orange-500"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold uppercase tracking-widest text-white/50">Chiqarilgan yili</label>
                <input 
                  type="number" required
                  value={formData.release_year}
                  onChange={(e) => setFormData({...formData, release_year: parseInt(e.target.value)})}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-orange-500"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold uppercase tracking-widest text-white/50">Turi</label>
                <select 
                  value={formData.type}
                  onChange={(e) => setFormData({...formData, type: e.target.value})}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-orange-500"
                >
                  <option value="TV">TV</option>
                  <option value="Movie">Film</option>
                  <option value="OVA">OVA</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold uppercase tracking-widest text-white/50">Holati</label>
                <select 
                  value={formData.status}
                  onChange={(e) => setFormData({...formData, status: e.target.value})}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-orange-500"
                >
                  <option value="Davom etmoqda">Davom etmoqda</option>
                  <option value="Tugallangan">Tugallangan</option>
                </select>
              </div>
              <div className="flex justify-end gap-4 md:col-span-2 pt-4">
                <button 
                  type="button" 
                  onClick={() => {
                    setShowModal(false);
                    setEditingAnime(null);
                  }}
                  className="px-6 py-3 rounded-xl font-bold hover:bg-white/5 transition-all"
                >
                  Bekor qilish
                </button>
                <button 
                  type="submit"
                  className="bg-orange-600 hover:bg-orange-700 text-white px-8 py-3 rounded-xl font-bold transition-all"
                >
                  {editingAnime ? 'Saqlash' : 'Qo\'shish'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
