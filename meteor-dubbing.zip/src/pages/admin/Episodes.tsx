import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useApi } from '../../hooks/useApi';
import { Plus, Trash2, Edit2, ChevronLeft, Play } from 'lucide-react';

export function AdminEpisodes() {
  const { animeId } = useParams();
  const api = useApi();
  const [anime, setAnime] = useState<any>(null);
  const [episodes, setEpisodes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingEpisode, setEditingEpisode] = useState<any>(null);
  
  const [formData, setFormData] = useState({
    episode_number: 1,
    title: '',
    video_url: '',
    duration: '24:00'
  });

  useEffect(() => {
    fetchData();
  }, [animeId]);

  const fetchData = async () => {
    try {
      const data = await api.get(`/api/anime/${animeId}`);
      setAnime(data);
      setEpisodes(data.episodes || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingEpisode) {
        await api.put(`/api/admin/episodes/${editingEpisode.id}`, formData);
      } else {
        await api.post('/api/admin/episodes', { ...formData, anime_id: animeId });
      }
      setShowModal(false);
      setEditingEpisode(null);
      fetchData();
      setFormData({ episode_number: episodes.length + 1, title: '', video_url: '', duration: '24:00' });
    } catch (e) {
      console.error(e);
    }
  };

  const handleEdit = (ep: any) => {
    setEditingEpisode(ep);
    setFormData({
      episode_number: ep.episode_number,
      title: ep.title,
      video_url: ep.video_url,
      duration: ep.duration
    });
    setShowModal(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Ushbu qismni o\'chirishga ishonchingiz komilmi?')) return;
    try {
      await api.delete(`/api/admin/episodes/${id}`);
      fetchData();
    } catch (e: any) {
      console.error(e);
      alert(e.message || 'O\'chirishda xatolik yuz berdi');
    }
  };

  if (loading) return <div className="py-20 text-center">Yuklanmoqda...</div>;

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <Link to="/admin/anime" className="text-orange-500 hover:text-orange-400 text-sm font-bold flex items-center gap-1">
            <ChevronLeft size={16} />
            Animelar ro'yxatiga qaytish
          </Link>
          <h1 className="text-4xl font-bold tracking-tight">{anime?.title}: Qismlar</h1>
        </div>
        <button 
          onClick={() => {
            setEditingEpisode(null);
            setFormData({ episode_number: episodes.length + 1, title: '', video_url: '', duration: '24:00' });
            setShowModal(true);
          }}
          className="bg-orange-600 hover:bg-orange-700 text-white px-6 py-3 rounded-2xl font-bold flex items-center gap-2 transition-all"
        >
          <Plus size={20} />
          Yangi qism qo'shish
        </button>
      </div>

      <div className="bg-white/5 rounded-[2.5rem] border border-white/10 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[600px]">
            <thead>
              <tr className="bg-white/5 text-white/50 text-xs font-bold uppercase tracking-widest">
                <th className="px-6 py-4">№</th>
                <th className="px-6 py-4">Sarlavha</th>
                <th className="px-6 py-4">Davomiyligi</th>
                <th className="px-6 py-4 text-right">Amallar</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {episodes.map((item) => (
                <tr key={item.id} className="hover:bg-white/5 transition-colors group">
                  <td className="px-6 py-4 font-bold text-orange-500">{item.episode_number}</td>
                  <td className="px-6 py-4 text-sm">{item.title}</td>
                  <td className="px-6 py-4 text-sm text-white/40">{item.duration}</td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => handleEdit(item)}
                        className="p-2 hover:bg-white/10 rounded-lg text-white/50 hover:text-white transition-colors"
                      >
                        <Edit2 size={16} />
                      </button>
                      <button 
                        onClick={() => handleDelete(item.id)}
                        className="p-2 hover:bg-red-500/10 rounded-lg text-white/50 hover:text-red-500 transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {episodes.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-6 py-12 text-center text-white/30">Hali qismlar qo'shilmagan.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#1a1a1a] w-full max-w-2xl rounded-[2.5rem] border border-white/10 p-8 max-h-[90vh] overflow-y-auto space-y-8">
            <h2 className="text-2xl font-bold">{editingEpisode ? 'Qismni tahrirlash' : 'Yangi qism qo\'shish'}</h2>
            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1">
                <label className="text-xs font-bold uppercase tracking-widest text-white/50">Qism raqami</label>
                <input 
                  type="number" required
                  value={formData.episode_number}
                  onChange={(e) => setFormData({...formData, episode_number: parseInt(e.target.value)})}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-orange-500"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold uppercase tracking-widest text-white/50">Davomiyligi</label>
                <input 
                  type="text" required
                  value={formData.duration}
                  onChange={(e) => setFormData({...formData, duration: e.target.value})}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-orange-500"
                  placeholder="24:00"
                />
              </div>
              <div className="space-y-1 md:col-span-2">
                <label className="text-xs font-bold uppercase tracking-widest text-white/50">Sarlavha</label>
                <input 
                  type="text" required
                  value={formData.title}
                  onChange={(e) => setFormData({...formData, title: e.target.value})}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-orange-500"
                />
              </div>
              <div className="space-y-1 md:col-span-2">
                <label className="text-xs font-bold uppercase tracking-widest text-white/50">Video URL (MP4 yoki YouTube)</label>
                <input 
                  type="text" required
                  value={formData.video_url}
                  onChange={(e) => setFormData({...formData, video_url: e.target.value})}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-orange-500"
                  placeholder="https://www.youtube.com/watch?v=... yoki .mp4 link"
                />
              </div>
              <div className="flex justify-end gap-4 md:col-span-2 pt-4">
                <button 
                  type="button" 
                  onClick={() => setShowModal(false)}
                  className="px-6 py-3 rounded-xl font-bold hover:bg-white/5 transition-all"
                >
                  Bekor qilish
                </button>
                <button 
                  type="submit"
                  className="bg-orange-600 hover:bg-orange-700 text-white px-8 py-3 rounded-xl font-bold transition-all"
                >
                  {editingEpisode ? 'Saqlash' : 'Qo\'shish'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
