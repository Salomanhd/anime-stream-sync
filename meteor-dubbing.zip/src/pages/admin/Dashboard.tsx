import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useApi } from '../../hooks/useApi';
import { Users, Film, PlayCircle, MessageSquare, TrendingUp, Activity } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

export function AdminDashboard() {
  const api = useApi();
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const data = await api.get('/api/admin/stats');
        setStats(data);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchStats();
  }, []);

  if (loading) return <div className="py-20 text-center">Statistika yuklanmoqda...</div>;

  const chartData = [
    { name: 'Foydalanuvchilar', value: stats.users.count },
    { name: 'Anime', value: stats.anime.count },
    { name: 'Qismlar', value: stats.episodes.count },
    { name: 'Fikrlar', value: stats.comments.count },
  ];

  const activityData = [
    { day: 'Du', views: 400 },
    { day: 'Se', views: 300 },
    { day: 'Ch', views: 600 },
    { day: 'Pa', views: 800 },
    { day: 'Ju', views: 500 },
    { day: 'Sha', views: 900 },
    { day: 'Yak', views: 1100 },
  ];

  return (
    <div className="space-y-12">
      <div className="flex items-center justify-between">
        <h1 className="text-4xl font-bold tracking-tight">Admin paneli</h1>
        <div className="flex items-center gap-2 text-sm font-medium text-white/50">
          <Activity size={16} className="text-green-500" />
          Tizim faol
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard icon={<Users />} label="Jami foydalanuvchilar" value={stats.users.count} color="bg-blue-500" />
        <StatCard icon={<Film />} label="Jami animelar" value={stats.anime.count} color="bg-purple-500" />
        <StatCard icon={<PlayCircle />} label="Qismlar" value={stats.episodes.count} color="bg-orange-500" />
        <StatCard icon={<MessageSquare />} label="Fikrlar" value={stats.comments.count} color="bg-pink-500" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Link to="/admin/anime" className="bg-white/5 p-8 rounded-3xl border border-white/10 hover:bg-white/10 transition-all group">
          <Film className="text-purple-500 mb-4 group-hover:scale-110 transition-transform" size={32} />
          <h3 className="text-xl font-bold">Animelarni boshqarish</h3>
          <p className="text-white/50 text-sm mt-2">Anime qo'shish, tahrirlash va o'chirish</p>
        </Link>
        <Link to="/admin/news" className="bg-white/5 p-8 rounded-3xl border border-white/10 hover:bg-white/10 transition-all group">
          <MessageSquare className="text-pink-500 mb-4 group-hover:scale-110 transition-transform" size={32} />
          <h3 className="text-xl font-bold">Yangiliklarni boshqarish</h3>
          <p className="text-white/50 text-sm mt-2">Yangiliklar qo'shish va tahrirlash</p>
        </Link>
        <Link to="/admin/users" className="bg-white/5 p-8 rounded-3xl border border-white/10 hover:bg-white/10 transition-all group">
          <Users className="text-blue-500 mb-4 group-hover:scale-110 transition-transform" size={32} />
          <h3 className="text-xl font-bold">Foydalanuvchilarni boshqarish</h3>
          <p className="text-white/50 text-sm mt-2">Premium berish va foydalanuvchilarni ko'rish</p>
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white/5 p-8 rounded-[2.5rem] border border-white/10 space-y-6">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <TrendingUp size={20} className="text-orange-500" />
            Platforma statistikasi
          </h2>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" vertical={false} />
                <XAxis dataKey="name" stroke="#ffffff50" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#ffffff50" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1a1a1a', border: 'none', borderRadius: '12px', color: '#fff' }}
                  itemStyle={{ color: '#f97316' }}
                />
                <Bar dataKey="value" fill="#f97316" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white/5 p-8 rounded-[2.5rem] border border-white/10 space-y-6">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Activity size={20} className="text-green-500" />
            Weekly Views
          </h2>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={activityData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" vertical={false} />
                <XAxis dataKey="day" stroke="#ffffff50" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#ffffff50" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1a1a1a', border: 'none', borderRadius: '12px', color: '#fff' }}
                  itemStyle={{ color: '#22c55e' }}
                />
                <Line type="monotone" dataKey="views" stroke="#22c55e" strokeWidth={3} dot={{ fill: '#22c55e', r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, color }: { icon: React.ReactNode, label: string, value: number, color: string }) {
  return (
    <div className="bg-white/5 p-6 rounded-3xl border border-white/10 space-y-4 hover:bg-white/10 transition-all cursor-default">
      <div className={`w-12 h-12 ${color} rounded-2xl flex items-center justify-center text-white shadow-lg`}>
        {icon}
      </div>
      <div>
        <p className="text-white/50 text-xs font-bold uppercase tracking-widest">{label}</p>
        <p className="text-3xl font-bold tracking-tight">{value.toLocaleString()}</p>
      </div>
    </div>
  );
}
