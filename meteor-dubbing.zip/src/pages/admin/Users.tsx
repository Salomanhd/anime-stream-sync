import React, { useState, useEffect } from 'react';
import { useApi } from '../../hooks/useApi';
import { User, Shield, ShieldCheck, Trash2 } from 'lucide-react';

export function AdminUsers() {
  const api = useApi();
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const data = await api.get('/api/admin/users');
      setUsers(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const togglePremium = async (userId: number, currentStatus: boolean) => {
    try {
      await api.post(`/api/admin/users/${userId}/premium`, { is_premium: !currentStatus });
      fetchUsers();
    } catch (e) {
      console.error(e);
    }
  };

  if (loading) return <div className="py-20 text-center">Foydalanuvchilar yuklanmoqda...</div>;

  return (
    <div className="space-y-8">
      <h1 className="text-4xl font-bold tracking-tight">Foydalanuvchilarni boshqarish</h1>

      <div className="bg-white/5 rounded-[2.5rem] border border-white/10 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[800px]">
            <thead>
              <tr className="bg-white/5 text-white/50 text-xs font-bold uppercase tracking-widest">
                <th className="px-6 py-4">Foydalanuvchi</th>
                <th className="px-6 py-4">Email</th>
                <th className="px-6 py-4">Rol</th>
                <th className="px-6 py-4">Premium</th>
                <th className="px-6 py-4">Sana</th>
                <th className="px-6 py-4 text-right">Amallar</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {users.map((u) => (
                <tr key={u.id} className="hover:bg-white/5 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center font-bold text-orange-500">
                        {u.username[0].toUpperCase()}
                      </div>
                      <span className="font-bold text-sm">{u.username}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-white/60">{u.email}</td>
                  <td className="px-6 py-4">
                    <span className={`text-[10px] font-bold px-2 py-1 rounded-full ${u.role === 'admin' ? 'bg-purple-500/10 text-purple-500' : 'bg-blue-500/10 text-blue-500'}`}>
                      {u.role.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    {u.is_premium ? (
                      <span className="flex items-center gap-1 text-orange-500 text-xs font-bold">
                        <ShieldCheck size={14} />
                        Premium
                      </span>
                    ) : (
                      <span className="text-white/30 text-xs">Oddiy</span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-xs text-white/40">{new Date(u.created_at).toLocaleDateString()}</td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => togglePremium(u.id, u.is_premium)}
                        className={`p-2 rounded-lg transition-colors ${u.is_premium ? 'hover:bg-red-500/10 text-red-500' : 'hover:bg-green-500/10 text-green-500'}`}
                        title={u.is_premium ? "Premiumni bekor qilish" : "Premium berish"}
                      >
                        <Shield size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
