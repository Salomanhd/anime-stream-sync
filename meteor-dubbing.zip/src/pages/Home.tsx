import { useState, useEffect } from 'react';
import { useApi } from '../hooks/useApi';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { Play, Star, ChevronRight, Crown } from 'lucide-react';

function AnimeCard({ anime, idx }: { anime: any, idx: number, key?: any }) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: idx * 0.1 }}
      className="group cursor-pointer"
    >
      <Link to={`/anime/${anime.id}`}>
        <div className="relative aspect-[2/3] rounded-xl overflow-hidden mb-3">
          <img 
            src={anime.image_url} 
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
            <div className="bg-orange-600 p-3 rounded-full transform scale-0 group-hover:scale-100 transition-transform">
              <Play size={24} fill="currentColor" />
            </div>
          </div>
          <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-md px-2 py-1 rounded text-[10px] font-bold flex items-center gap-1">
            <Star size={10} className="text-orange-500" fill="currentColor" />
            {anime.rating}
          </div>
        </div>
        <h3 className="font-bold text-sm line-clamp-1 group-hover:text-orange-500 transition-colors">{anime.title}</h3>
        <p className="text-xs text-white/50">{anime.release_year} • {anime.type}</p>
      </Link>
    </motion.div>
  );
}

export function Home() {
  const api = useApi();
  const [trending, setTrending] = useState<any[]>([]);
  const [ongoing, setOngoing] = useState<any[]>([]);
  const [genres, setGenres] = useState<any[]>([]);
  const [news, setNews] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [popularData, ongoingData, genresData, newsData] = await Promise.all([
          api.get('/api/anime?sort=popular'),
          api.get('/api/anime?status=Davom etmoqda'),
          api.get('/api/genres'),
          api.get('/api/news')
        ]);
        setTrending(popularData.slice(0, 6));
        setOngoing(ongoingData.slice(0, 6));
        setGenres(genresData);
        setNews(newsData.slice(0, 3));
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) return <div className="py-20 text-center">Loading...</div>;

  return (
    <div className="space-y-16">
      {/* Trending Section */}
      <section>
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-bold tracking-tight">Trenddagi animelar</h2>
          <Link to="/catalog?sort=popular" className="text-orange-500 hover:text-orange-400 flex items-center gap-1 text-sm font-bold">
            Hammasini ko'rish <ChevronRight size={16} />
          </Link>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
          {trending.map((anime, idx) => (
            <AnimeCard key={anime.id} anime={anime} idx={idx} />
          ))}
        </div>
      </section>

      {/* Ongoing Section */}
      <section>
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-bold tracking-tight">Davom etayotgan (Ongoing)</h2>
          <Link to="/catalog?status=Davom etmoqda" className="text-orange-500 hover:text-orange-400 flex items-center gap-1 text-sm font-bold">
            Hammasini ko'rish <ChevronRight size={16} />
          </Link>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
          {ongoing.map((anime, idx) => (
            <AnimeCard key={anime.id} anime={anime} idx={idx} />
          ))}
        </div>
      </section>

      {/* Genres Section */}
      <section>
        <h2 className="text-3xl font-bold tracking-tight mb-8">Janrlar</h2>
        <div className="flex flex-wrap gap-4">
          {genres.map((genre) => (
            <Link 
              key={genre.id} 
              to={`/catalog?genre=${genre.name}`}
              className="bg-white/5 hover:bg-orange-600 border border-white/10 hover:border-orange-500 px-6 py-3 rounded-2xl font-bold transition-all"
            >
              {genre.name}
            </Link>
          ))}
        </div>
      </section>

      {/* News Section */}
      <section className="space-y-8">
        <div className="flex items-center justify-between">
          <h2 className="text-3xl font-bold tracking-tight">So'nggi yangiliklar</h2>
          <Link to="/news" className="text-orange-500 hover:text-orange-400 flex items-center gap-1 text-sm font-bold">
            Barcha yangiliklar <ChevronRight size={16} />
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {news.map((item) => (
            <div key={item.id} className="group space-y-4">
              <div className="aspect-video rounded-3xl overflow-hidden border border-white/10">
                <img 
                  src={item.image_url} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="space-y-2">
                <h3 className="font-bold text-xl group-hover:text-orange-500 transition-colors line-clamp-2">{item.title}</h3>
                <p className="text-sm text-white/50">{new Date(item.created_at).toLocaleDateString()}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Premium Banner */}
      <section className="bg-gradient-to-r from-orange-600 to-orange-400 rounded-[3rem] p-8 md:p-16 text-white relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform">
          <Crown size={200} fill="currentColor" />
        </div>
        <div className="relative z-10 max-w-2xl space-y-6">
          <h2 className="text-4xl md:text-6xl font-black tracking-tighter">PREMIUMGA O'TING!</h2>
          <p className="text-lg md:text-xl text-white/90 font-medium">
            Sevimli ijodkorlaringizni qo'llab-quvvatlang va reklamasiz tomosha qilish, oflayn ko'rish va yangi qismlarga erta kirish imkoniyatiga ega bo'ling.
          </p>
          <button className="bg-white text-orange-600 px-8 py-4 rounded-full font-black tracking-widest uppercase hover:bg-orange-50 transition-all shadow-xl shadow-orange-900/20">
            Hozir yangilang
          </button>
        </div>
      </section>
    </div>
  );
}
