import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useApi } from '../hooks/useApi';
import { User, Mail, Shield, Crown, Clock } from 'lucide-react';

export function Profile() {
  const { user } = useAuth();
  const api = useApi();
  const [history, setHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchHistory = async () => {
      try {
        const data = await api.get('/api/history');
        setHistory(data);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    if (user) fetchHistory();
  }, [user]);

  if (!user) return <div className="py-20 text-center">Please log in to view your profile.</div>;

  return (
    <div className="max-w-4xl mx-auto space-y-12">
      <div className="bg-white/5 rounded-[2.5rem] p-8 md:p-12 border border-white/10 flex flex-col md:flex-row gap-8 items-center">
        <div className="w-32 h-32 rounded-full bg-orange-600 flex items-center justify-center text-5xl font-bold shadow-2xl shadow-orange-600/20">
          {user.username[0].toUpperCase()}
        </div>
        <div className="space-y-4 text-center md:text-left">
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-3">
            <h1 className="text-4xl font-bold tracking-tight">{user.username}</h1>
            {user.is_premium ? (
              <span className="bg-yellow-500/20 text-yellow-500 border border-yellow-500/30 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                <Crown size={12} fill="currentColor" />
                PREMIUM
              </span>
            ) : (
              <span className="bg-white/10 text-white/50 border border-white/20 px-3 py-1 rounded-full text-xs font-bold">
                FREE USER
              </span>
            )}
            {user.role === 'admin' && (
              <span className="bg-orange-500/20 text-orange-500 border border-orange-500/30 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                <Shield size={12} fill="currentColor" />
                ADMIN
              </span>
            )}
          </div>
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-6 text-white/50 text-sm">
            <div className="flex items-center gap-2">
              <Mail size={16} />
              {user.email}
            </div>
            <div className="flex items-center gap-2">
              <Clock size={16} />
              Qo'shilgan sana: {new Date().toLocaleDateString()}
            </div>
          </div>
        </div>
      </div>

      <section className="space-y-6">
        <h2 className="text-2xl font-bold tracking-tight">Ko'rish tarixi</h2>
        {loading ? (
          <div className="text-center py-10 text-white/50">Yuklanmoqda...</div>
        ) : history.length === 0 ? (
          <div className="bg-white/5 rounded-3xl p-12 text-center text-white/50 border border-dashed border-white/10">
            Ko'rish tarixingiz bo'sh. Anime ko'rishni boshlang!
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {history.map((item) => (
              <div key={item.id} className="bg-white/5 border border-white/10 rounded-2xl p-4 flex gap-4 hover:bg-white/10 transition-all group">
                <div className="w-24 aspect-video rounded-lg overflow-hidden shrink-0">
                  <img src={item.image_url} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
                <div className="min-w-0">
                  <h3 className="font-bold text-sm truncate">{item.anime_title}</h3>
                  <p className="text-xs text-white/50">{item.episode_number}-qism: {item.episode_title}</p>
                  <p className="text-[10px] text-orange-500 mt-1">{new Date(item.watched_at).toLocaleString()}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
