import { useState, useEffect } from 'react';
import { useApi } from '../hooks/useApi';
import { Link, useSearchParams } from 'react-router-dom';
import { Search, Filter, Star, Play } from 'lucide-react';
import { motion } from 'motion/react';

export function Catalog() {
  const api = useApi();
  const [searchParams, setSearchParams] = useSearchParams();
  const [anime, setAnime] = useState<any[]>([]);
  const [genres, setGenres] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const currentGenre = searchParams.get('genre') || '';
  const currentSearch = searchParams.get('search') || '';
  const currentSort = searchParams.get('sort') || 'new';
  const currentStatus = searchParams.get('status') || '';

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [animeData, genreData] = await Promise.all([
          api.get(`/api/anime?genre=${currentGenre}&search=${currentSearch}&sort=${currentSort}&status=${currentStatus}`),
          api.get('/api/genres')
        ]);
        setAnime(animeData);
        setGenres(genreData);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [currentGenre, currentSearch, currentSort, currentStatus]);

  const handleGenreChange = (genre: string) => {
    const params = new URLSearchParams(searchParams);
    if (genre) params.set('genre', genre);
    else params.delete('genre');
    setSearchParams(params);
  };

  const handleSortChange = (sort: string) => {
    const params = new URLSearchParams(searchParams);
    params.set('sort', sort);
    setSearchParams(params);
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h1 className="text-4xl font-bold tracking-tight">Anime katalogi</h1>
        <div className="flex items-center gap-4">
          <select 
            value={currentSort}
            onChange={(e) => handleSortChange(e.target.value)}
            className="bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-orange-500"
          >
            <option value="new">Yangi</option>
            <option value="popular">Mashhur</option>
            <option value="old">Eski</option>
          </select>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => handleGenreChange('')}
          className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${!currentGenre ? 'bg-orange-600 text-white' : 'bg-white/5 hover:bg-white/10 text-white/70'}`}
        >
          Hammasi
        </button>
        {genres.map((g) => (
          <button
            key={g.id}
            onClick={() => handleGenreChange(g.name)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${currentGenre === g.name ? 'bg-orange-600 text-white' : 'bg-white/5 hover:bg-white/10 text-white/70'}`}
          >
            {g.name}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="py-20 text-center">Loading catalog...</div>
      ) : (
        <>
          {anime.length === 0 ? (
            <div className="py-20 text-center text-white/50">No anime found matching your criteria.</div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
              {anime.map((item, idx) => (
                <motion.div 
                  key={item.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: idx * 0.05 }}
                  className="group"
                >
                  <Link to={`/anime/${item.id}`}>
                    <div className="relative aspect-[2/3] rounded-xl overflow-hidden mb-3">
                      <img 
                        src={item.image_url} 
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <div className="bg-orange-600 p-3 rounded-full transform scale-0 group-hover:scale-100 transition-transform">
                          <Play size={24} fill="currentColor" />
                        </div>
                      </div>
                      <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-md px-2 py-1 rounded text-[10px] font-bold flex items-center gap-1">
                        <Star size={10} className="text-orange-500" fill="currentColor" />
                        {item.rating}
                      </div>
                    </div>
                    <h3 className="font-bold text-sm line-clamp-1 group-hover:text-orange-500 transition-colors">{item.title}</h3>
                    <p className="text-xs text-white/50">{item.release_year} • {item.type}</p>
                  </Link>
                </motion.div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
