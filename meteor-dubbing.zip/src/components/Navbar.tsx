import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Search, User, LogOut, LayoutDashboard, Crown } from 'lucide-react';

export function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (search.trim()) {
      navigate(`/catalog?search=${search}`);
    }
  };

  return (
    <nav className="bg-[#0a0502]/80 backdrop-blur-md sticky top-0 z-50 border-b border-white/10">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-8">
          <Link to="/" className="group flex items-center gap-2">
            <div className="bg-orange-600 p-1.5 rounded-lg rotate-12 group-hover:rotate-0 transition-transform">
              <div className="bg-white p-0.5 rounded-sm">
                <div className="w-4 h-4 bg-orange-600 rounded-full" />
              </div>
            </div>
            <span className="text-xl md:text-2xl font-black tracking-tighter text-white italic">
              METEOR<span className="text-orange-500 not-italic">DUBBING</span>
            </span>
          </Link>
          <div className="hidden md:flex items-center gap-6 text-sm font-medium text-white/70">
            <Link to="/" className="hover:text-white transition-colors">Bosh sahifa</Link>
            <Link to="/catalog" className="hover:text-white transition-colors">Katalog</Link>
            {user && <Link to="/watchlist" className="hover:text-white transition-colors">Saqlanganlar</Link>}
          </div>
        </div>

        <div className="flex items-center gap-4">
          <form onSubmit={handleSearch} className="relative hidden sm:block">
            <input
              type="text"
              placeholder="Anime qidirish..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="bg-white/5 border border-white/10 rounded-full py-1.5 pl-4 pr-10 text-sm focus:outline-none focus:border-orange-500/50 w-48 lg:w-64 transition-all"
            />
            <button type="submit" className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white">
              <Search size={16} />
            </button>
          </form>

          {user ? (
            <div className="flex items-center gap-4">
              {user.is_premium && (
                <div className="hidden md:flex items-center gap-1 bg-yellow-500/20 text-yellow-500 border border-yellow-500/30 px-3 py-1 rounded-full text-[10px] font-black tracking-widest uppercase">
                  <Crown size={10} fill="currentColor" />
                  Premium
                </div>
              )}
              {user.role === 'admin' && (
                <Link to="/admin" className="p-2 hover:bg-white/5 rounded-full text-white/70 hover:text-white transition-colors" title="Admin paneli">
                  <LayoutDashboard size={20} />
                </Link>
              )}
              <Link to="/profile" className="p-2 hover:bg-white/5 rounded-full text-white/70 hover:text-white transition-colors" title="Profil">
                <User size={20} />
              </Link>
              <button onClick={logout} className="p-2 hover:bg-white/5 rounded-full text-white/70 hover:text-white transition-colors" title="Chiqish">
                <LogOut size={20} />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Link to="/login" className="text-sm font-medium px-4 py-2 hover:text-orange-500 transition-colors">Kirish</Link>
              <Link to="/register" className="text-sm font-medium bg-orange-600 hover:bg-orange-700 px-4 py-2 rounded-full transition-colors">Ro'yxatdan o'tish</Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}
