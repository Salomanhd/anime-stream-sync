export function Footer() {
  return (
    <footer className="bg-[#0a0502] border-t border-white/10 py-12 mt-20">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <h2 className="text-2xl font-bold tracking-tighter text-orange-500 mb-4">METEOR DUBBING</h2>
            <p className="text-white/50 max-w-md">
              Anime muxlislari uchun eng yaxshi manzil. Sevimli seriallaringizni yuqori sifatda, o'zbek tilidagi dublyaj bilan tomosha qiling.
            </p>
          </div>
          <div>
            <h3 className="font-bold mb-4">Tezkor havolalar</h3>
            <ul className="space-y-2 text-white/50 text-sm">
              <li><a href="#" className="hover:text-white">Biz haqimizda</a></li>
              <li><a href="#" className="hover:text-white">Xizmat ko'rsatish shartlari</a></li>
              <li><a href="#" className="hover:text-white">Maxfiylik siyosati</a></li>
              <li><a href="#" className="hover:text-white">Aloqa</a></li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold mb-4">Hamjamiyat</h3>
            <ul className="space-y-2 text-white/50 text-sm">
              <li><a href="#" className="hover:text-white">Telegram</a></li>
              <li><a href="#" className="hover:text-white">Instagram</a></li>
              <li><a href="#" className="hover:text-white">YouTube</a></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-white/5 mt-12 pt-8 text-center text-white/30 text-xs">
          © 2026 Meteor dubbing. Barcha huquqlar himoyalangan.
        </div>
      </div>
    </footer>
  );
}
