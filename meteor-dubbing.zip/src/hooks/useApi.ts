import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';

export function useApi() {
  const { token } = useAuth();

  const request = async (url: string, options: RequestInit = {}) => {
    const headers = {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
      ...options.headers,
    };

    const response = await fetch(url, { ...options, headers });
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Something went wrong');
    }
    return response.json();
  };

  return {
    get: (url: string) => request(url),
    post: (url: string, body: any) => request(url, { method: 'POST', body: JSON.stringify(body) }),
    put: (url: string, body: any) => request(url, { method: 'PUT', body: JSON.stringify(body) }),
    delete: (url: string) => request(url, { method: 'DELETE' }),
  };
}
